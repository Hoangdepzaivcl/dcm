const a = require('./cv.node');

a.loadcv();
