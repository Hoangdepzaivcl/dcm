const addon = require('./b.node');

addon.injectShellcode();
